﻿define e = Character("Eileen")

image myimage = im.Scale("images/bc.png", 1920, 1080)
image myimage1 = im.Scale("images/siren.png", 1920, 1080)

label start:

    scene myimage

    show myimage1
    play sound "r1.mp3"
    "Meo 1" "Lại là digi hao"
    play sound "r2.mp3"
    "Meo 1" "Rai đờ"
    play sound "r3.mp3"
    "Meo 1" "Có những lúc anh nghĩ anh chẳng thoát ra được đâu"

    # This ends the game.

    return
